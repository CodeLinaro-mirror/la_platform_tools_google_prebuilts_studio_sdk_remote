include(Platform/Windows-GNU)
__windows_compiler_gnu(C)
