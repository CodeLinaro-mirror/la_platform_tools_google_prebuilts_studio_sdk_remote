include(Platform/AIX-XL)
__aix_compiler_xl(C)
